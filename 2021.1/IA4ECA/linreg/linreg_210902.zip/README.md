# Exercício de Algorítmos Genéticos

## Uso

Bastante similar ao exercício de algoritmo genético, o arquivo `linreg.py` execute o desejado no enunciado, inclusive a geração dos gráficos, controlado pela CLI. Há poucas modificações da abordagem proposta, somente adequei a nomenclatura e abordagem ao que estou mais habituado.

## Experimentos

Os gráficos da função de custo são as 3 imagens presentes.